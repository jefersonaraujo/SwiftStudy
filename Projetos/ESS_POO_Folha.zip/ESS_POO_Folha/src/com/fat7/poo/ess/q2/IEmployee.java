package com.fat7.poo.ess.q2;

public interface IEmployee {

	void receiveSalary();
	void hitPoint();
	void work();
	
}
