package com.fat7.poo.ess.q2;

public interface ITrainee {

	void receiveMoney();
	void regEntry();
	void regExit();
	void traineer();
	
}
